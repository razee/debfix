"yaXamp"

Skin made by Razor for yaxay.com. Hope you like it! it's my first WA skin.
 
Thanks goes to the maker of "Template Amp" for making skinning easier. ;P

wOOt to all yaxayians! 